#!/usr/bin/env python3
"""
run_server.py — Waitress entrypoint with CLI args

Usage examples:
  python run_server.py
  python run_server.py --host 0.0.0.0 --port 8080
  python run_server.py --no-ui
"""
import argparse
import threading
from waitress import serve
from src import swarm_core


def _start_background_loop():
    # Start the asyncio tick loop in a background thread (swarm_core.start_asyncio does loop setup)
    t = threading.Thread(target=swarm_core.start_asyncio, daemon=True)
    t.start()
    return t


def main():
    parser = argparse.ArgumentParser(description="Foxhunter Swarm Server")
    parser.add_argument("--host", default="0.0.0.0", help="Host address (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=5000, help="Port number (default: 5000)")
    parser.add_argument("--no-ui", action="store_true", help="Disable web UI")
    args = parser.parse_args()

    print(f"🚀 Starting Swarm on {args.host}:{args.port} (UI={'off' if args.no_ui else 'on'})")
    swarm_core.init_db()
    swarm_core.swarm.init_agents(swarm_core.NUM_AGENTS)

    # Start the background asyncio tick loop so agents run
    _start_background_loop()

    if args.no_ui:
        print("Running in headless mode (no UI). Press Ctrl-C to exit.")
        try:
            # Block forever until interrupted
            threading.Event().wait()
        except KeyboardInterrupt:
            print("Shutting down (keyboard interrupt)")
        return

    serve(swarm_core.APP, host=args.host, port=args.port)


if __name__ == "__main__":
    main()