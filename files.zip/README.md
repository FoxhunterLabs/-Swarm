# Swarm

Polished system overview
------------------------

Swarm is a small, well-structured Python project template for building and experimenting with cooperative multi-agent systems. It provides a minimal, extensible core for agent coordination, a simple human-facing hub (HTTP dashboard), utilities for logging and audit trails, and example scripts for local simulation.

Project layout
--------------

swarm/
- README.md                — this overview and quickstart
- .gitignore               — recommended ignores
- requirements.txt         — installable Python dependencies
- src/                     — core Python implementation
  - swarm_core.py          — core coordination logic (heart of the system)
  - swarm_agent.py         — agent behavior & communication loop
  - swarm_hub.py           — human-gate & sync manager (operator interface)
  - swarm_utils.py         — utilities (logging, hashing, audit helpers)
- static/
  - dashboard.html         — simple local dashboard for swarm state
- logs/                    — runtime telemetry & agent logs (ignored by Git)
- audit/                   — SHA-256 audit trail files (ignored by Git)
- telemetry/               — optional data snapshots (ignored by Git)
- examples/
  - example_sim.py         — local simulation demo
  - example_real.py        — placeholder for a future real-world runner
- LICENSE

Design principles
-----------------
- Lightweight and dependency-minimal. Core coordination is asyncio-friendly.
- Clear separation of concerns: agents, coordinator, human hub, utilities.
- Audit-first mindset: every important action can be appended to an SHA-256 based audit trail for offline verification.
- Easy to extend: swap in network transports, richer UI, persistence, or real robot integrations.

Quickstart (recommended)
------------------------
1. Create a virtualenv and install dependencies:
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt

2. Run the local simulation:
   python examples/example_sim.py

3. (Optional) Start the human hub to get the dashboard:
   python -m src.swarm_hub
   Open http://127.0.0.1:5000/dashboard

File summaries
--------------
- src/swarm_core.py — Orchestrates agent registration and message routing. Provides a simulation-friendly API (register_agent, broadcast, collect_telemetry).
- src/swarm_agent.py — A simple asyncio-based Agent class with a run loop, heartbeat, and task execution hook.
- src/swarm_hub.py — Small Flask app exposing status endpoints and serving static/dashboard.html.
- src/swarm_utils.py — Logging setup, agent id generation, timestamp helpers, and audit-trail writer.

Contributing
------------
Contributions are welcome. File an issue with a clear proposal or open a pull request.

License
-------
MIT — see LICENSE file.