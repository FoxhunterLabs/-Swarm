#!/usr/bin/env bash
set -euo pipefail

# Create and activate a Python virtual environment, then install requirements.
# Usage: ./scripts/setup_env.sh
# Note: This script creates a venv directory in the repo root. If you prefer
# a dot-venv like ".venv" update the VENV_DIR variable below.

VENV_DIR="venv"
REQ_FILE="requirements.txt"

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 not found in PATH. Please install Python 3.8+."
  exit 2
fi

echo "Creating virtual environment at ${VENV_DIR}..."
python3 -m venv "${VENV_DIR}"

# shellcheck disable=SC1090
source "${VENV_DIR}/bin/activate"

echo "Upgrading pip..."
pip install --upgrade pip

if [ -f "${REQ_FILE}" ]; then
  echo "Installing dependencies from ${REQ_FILE}..."
  pip install -r "${REQ_FILE}"
else
  echo "No ${REQ_FILE} found. Skipping pip install."
fi

echo "Swarm environment ready."